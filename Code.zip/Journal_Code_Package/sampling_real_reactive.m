function[]=sampling_real_reactive()
an = 0;                                             % set 1 to recompute
if an == 1
%% real power
input_F1=[];
input_F2=[];
output_F1=[];
output_F2=[];
load out
for i=1:100
    input_F1=[input_F1;[datasample(out(1, i).V_I_1.signals(1).values,200)]];
    input_F2=[input_F2;[datasample(out(1, i).V_I_2.signals(1).values,200)]];
    output_F1=[output_F1;[datasample(out(1, i).PQ1.signals(1).values,200)]];
    output_F2=[output_F2;[datasample(out(1, i).PQ2.signals(1).values,200)]];

end
% save input_F1 input_F1
% save input_F2 input_F2
% save output_F1 output_F1
% save output_F2 output_F2

%% reactive power
input_F11=[];
input_F21=[];
output_F11=[];
output_F21=[];
% load out
for j=1:100
    input_F11=[input_F11;[datasample(out(1, j).V_I_1.signals(1).values,200)]];
    input_F21=[input_F21;[datasample(out(1, j).V_I_2.signals(1).values,200)]];
    output_F11=[output_F11;[datasample(out(1, j).PQ1.signals(2).values,200)]];
    output_F21=[output_F21;[datasample(out(1, j).PQ2.signals(2).values,200)]];

end
% save input_F11 input_F11
% save input_F21 input_F21
% save output_F11 output_F11
% save output_F21 output_F21
end
end