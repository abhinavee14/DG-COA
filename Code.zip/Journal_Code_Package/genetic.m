function[bestfit,bestfitness,bestsol,time] = genetic(val,objfun,L,U,itermax)
[N,D] = size(val);
 cases=1;         		%no. of Monte Carlo cases  
 p=D;            			%dimension of theta
 P_c=0.6;         			%crossover rate
 P_m=0.1;      			%mutation sigma
 elite=2;                %no. of population elements for "elitism" 
 lb=min(L); ub=max(U);
 thetamin= lb;  		%lower bounds on theta elements
 thetamax= ub;   	%upper bounds: ditto
for c=1:cases
   thetapop = val;  
   % Evaluation of fitness for initial population
  
   fitness = feval(objfun,thetapop);%N by 1 vector of fitness values
 
   [bestfitness,bestindex]=min(fitness); 
   %
   % Main loop of GA
   %
   index=zeros(elite,1);
   %cumfit=zeros(N-elite,1);   
   tic;
   for n = 1:itermax
      % Invoke elitism for 'elite' best chromosomes
      temp_fit=fitness;
      for j=1:elite
         [junk,index(j)]=min(temp_fit);
         temp_fit(index(j))=min(temp_fit);
      end
      for j=1:2:N-elite-1
          
         % Tournament selection below.  Uses tournament size = 2.  
%             cand=ceil(N*rand(2,1));  %picks two candidate parents
              cand = randi([1,N],[2,1]);  
              a = fitness(cand(1));
              b = fitness(cand(2));
            
         if a>=b
            parent1_idx=cand(1);
         else
            parent1_idx=cand(2);
         end   
%          cand=ceil(N*rand(2,1));  %ditto-for picking other parent 
             cand = randi([1,N],[2,1]);  
         if fitness(cand(1))>fitness(cand(2))
            parent2_idx=cand(1);
         else
            parent2_idx=cand(2);
         end
         % Crossover with above two parents
         if rand < P_c
            cross_point=ceil(rand*(p-1)); %an integer 1,...,p-1
            parent1=thetapop(parent1_idx,:);
            %above picks off the chrom. for parent1_idx
            parent2=thetapop(parent2_idx,:);
            %above picks off the chrom. for parent2_idx
            child1=[parent1(1:cross_point),...  
               parent2(cross_point+1:p)];   %merges parents1&2
            child2=[parent2(1:cross_point),...
               parent1(cross_point+1:p)];   %merges parents1&2
            thetapop_noelite(j,:)=child1;%assigns child1 to new chrom. matrix
            thetapop_noelite(j+1,:)=child2;%ditto for child2 
         else
            parent1=thetapop(parent1_idx,:);
               %above picks off the chrom. for parent1_idx
            parent2=thetapop(parent2_idx,:);
               %above picks off the chrom. for parent2_idx
            thetapop_noelite(j,:)=parent1;%assigns parent1 to chrom. matrix
            thetapop_noelite(j+1,:)=parent2;%ditto for parent2 
         end
      end
      %
      % Mutation operator applied to thetapop_noelite vector (elite  
      % chromosomes not subject to mutation)by addition of Gauss.
      % random vector with diag. cov. matrix (standard devs. = P_m)
      %
      thetapop_noelite=thetapop_noelite+P_m*randn(N-elite,p);
      %
      % Invoke constraints to above population
      %
      for j=1:N-elite
         thetapop_noelite(j,:)=min(thetapop_noelite(j,:),thetamax);
         thetapop_noelite(j,:)=max(thetapop_noelite(j,:),thetamin);
      end
      %
      % Put elite chromosomes (theta values) back in population
      %
      for j=1:elite
        thetapop(j,:)=thetapop(index(j),:);
      end
      thetapop(elite+1:N,:)=thetapop_noelite;
      
%          fitness =-feval(loss,thetapop(i,:)');
      fitness = feval(objfun,thetapop);      
      [bestfitness(n),bestindex]=min(fitness);
     bestsol{n} = thetapop(bestindex,:);  
   end
   time = toc;
end
bestfitness=sort(bestfitness,'descend');
bestfit = bestfitness(end);
end