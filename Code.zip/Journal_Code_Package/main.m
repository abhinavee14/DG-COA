function[]=main()
%% data collect
Data_collect_simulink()
%% real and reactive load(sampling)
sampling_real_reactive()
%% data normalization
normaliz()
%% feature extraction for real load
feat_ext()
%% feature extraction for reactive load
feat_ext1()
%% optimization
main1()
%% Analysis
Testing()
%% results
 convergence()
 plot_result()   %% real load
 plot_result1()  %% reactive load
end