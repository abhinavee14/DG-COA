function[fit] = Objfun1(soln)
for k=1:size(soln,1)
sol = soln(k,:);
%%real power
alpha_p(1,:)=sol(5:14);
alpha_p(2,:)=sol(15:24);
alpha_p(3,:)=sol(25:34);
alpha_p(4,:)=sol(35:44);
alpha_p(5,:)=sol(45:54);
alpha_p(6,:)=sol(55:64);
alpha_p1=sol(65:74)';
gamma_p=sol(75:84)';

%% real power
load FVector
for ii=1:length(FVector)
    xmax=FVector(:,2);    %% max
    x1=FVector(:,1);      %% min
    x2=FVector(:,3);      %% mean
    x3=FVector(:,4);      %% median
    x4=FVector(:,2);      %% max
    x5=FVector(:,5);      %% std
    x6=FVector(:,6);      %% entropy
    xx1(ii)=x1(ii)/xmax(ii);
    xx2(ii)=x2(ii)/xmax(ii);
    xx3(ii)=x3(ii)/xmax(ii);
    xx4(ii)=x4(ii)/xmax(ii);
            
xx(ii,:)=[xx1(ii) xx2(ii) xx3(ii) xx4(ii)];
S(ii,:)=1-sol(1:4).*tanh(xx(ii,:));
s1(ii,:)=[S(ii,:) x5(ii) x6(ii)];
for i=1:6
    for j=1:10
H(j,:)=1./(1+exp(-((alpha_p(i,j).*s1(i))+alpha_p1(j))));
gamma_p1=rand;
P_=(H(j)*gamma_p(j))+(gamma_p1);
    end
end
P(ii)=P_;
end
%%reactive power
alpha_Q(1,:)=sol(85:94);
alpha_Q(2,:)=sol(95:104);
alpha_Q(3,:)=sol(105:114);
alpha_Q(4,:)=sol(115:124);
alpha_Q(5,:)=sol(125:134);
alpha_Q(6,:)=sol(135:144);
alpha_Q1=sol(145:154)';
gamma_Q=sol(155:164)';
%% reactive power
load FVector1
for jj=1:length(FVector1)
    x_max=FVector1(:,2);    %% max
    x_1=FVector1(:,1);      %% min
    x_2=FVector1(:,3);      %% mean
    x_3=FVector1(:,4);      %% median
    x_4=FVector1(:,2);      %% max
    x_5=FVector1(:,5);      %% std
    x_6=FVector1(:,6);      %% entropy
    xx_1(jj)=x_1(jj)/x_max(jj);
    xx_2(jj)=x_2(jj)/x_max(jj);
    xx_3(jj)=x_3(jj)/x_max(jj);
    xx_4(jj)=x_4(jj)/x_max(jj);
            
x_x(jj,:)=[xx_1(jj) xx_2(jj) xx_3(jj) xx_4(jj)];
S_(jj,:)=1-sol(1:4).*tanh(x_x(jj,:));
s_1(jj,:)=[S_(jj,:) x_5(jj) x_6(jj)];
for a=1:6
    for b=1:10
H_1(b,:)=1./(1+exp(-((alpha_Q(a,b).*s_1(a))+alpha_Q1(b))));
gamma_Q1=rand;
P_1=(H_1(b)*gamma_Q(b))+(gamma_Q1);
    end
end
Q(jj)=P_1;
end
%% error1
load d1 
load d2
DD1=[d1;d2];
act=DD1(:,4);
err1=abs(act-P');
%% error2
load d3
load d4
DD2=[d3;d4];
act=DD2(:,4);
err2=abs(act-Q');
err=err1+err2;
fit(k)=mean(err);
end
end

