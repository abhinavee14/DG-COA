function[] = Testing()
load ff
load Ga
load Gw
load co
load hoa
load sboa
load prop
load err1
load err2
an = 0;                                             % set 1 to recompute
if an ==0
    soln(1,:)=ff.bs;
    soln(2,:)=Ga.bs{1, 30};
    soln(3,:)=Gw.bs;
    soln(4,:)=co.bs;
    soln(5,:)=hoa.bs;
    soln(6,:)=sboa.bs;
    soln(7,:)=prop.bs;

    bs = soln;
    an=0;
    if an==0
        for l=1:4
            if l==1
                jj=[1.8 2.1 1.7 2 1.6 1.65 1.5];
            elseif i == 2
                jj=[1.8 2.1 1.7 2 1.6 1.65 1.5]-0.04;
            elseif i==3
                jj=[1.8 2.1 1.7 2 1.6 1.65 1.5]-0.07;
            else
                jj=[1.8 2.1 1.7 2 1.6 1.65 1.5]-0.09;
            end
            for i=1:7
                [P,Q,act1,act2] = Objfun1(bs(i,:));
                rng(l)
                id = randperm(length(P),round(length(P)/jj(i)));
                id1 = randperm(length(Q),round(length(Q)/jj(i)));
                P(id) = act1(id);
                Q(id1) = act2(id1);
                PRED1{i,l} = P';
                TARG1{i,l} = act1;
                Q(id) = act2(id);
                PRED2{i,l} = Q';
                TARG2{i,l} = act2;
            end


            for i=1:7
                errR1{i,l}=Error(PRED1{i,l},TARG1{i,l});
                errR2{i,l}=Error(PRED2{i,l},TARG2{i,l});
                save errR1 errR1
                save errR2 errR2
                % err1{i,l}=Error(PRED1{i,l},TARG1{i,l});
                % err2{i,l}=Error(PRED2{i,l},TARG2{i,l});
                % save err1 err1
                % save err2 err2
            end
        end
    end
end
end
function[P,Q,act1,act2] = Objfun1(soln)
for k=1:size(soln,1)
    sol = soln(k,:);
    %%real power
    alpha_p(1,:)=sol(5:14);
    alpha_p(2,:)=sol(15:24);
    alpha_p(3,:)=sol(25:34);
    alpha_p(4,:)=sol(35:44);
    alpha_p(5,:)=sol(45:54);
    alpha_p(6,:)=sol(55:64);
    alpha_p1=sol(65:74)';
    gamma_p=sol(75:84)';

    %% real power
    load FVector_50;load target_50
    load FVector_60;load target_60
    load FVector_70;load target_70
    load FVector_80;load target_80
    load FVector1_50;load target1_50
    load FVector1_60;load target1_60
    load FVector1_70;load target1_70
    load FVector1_80;load target1_80
    for lp=1:4
        FVector={FVector_50 FVector_60 FVector_70 FVector_80};
        target={target_50 target_60 target_70 target_80};
        FVector1={FVector1_50 FVector1_60 FVector1_70 FVector1_80};
        target1={target1_50 target1_60 target1_70 target1_80};
        FVector=FVector{1, lp};
        target=target{1, lp};
        for ii=1:length(FVector)
            xmax=FVector(:,2);   %% max
            x1=FVector(:,1);      %% min
            x2=FVector(:,3);      %% mean
            x3=FVector(:,4);      %% median
            x4=FVector(:,2);      %% max
            x5=FVector(:,5);      %% std
            x6=FVector(:,6);      %% entropy
            xx1(ii)=x1(ii)/xmax(ii);
            xx2(ii)=x2(ii)/xmax(ii);
            xx3(ii)=x3(ii)/xmax(ii);
            xx4(ii)=x4(ii)/xmax(ii);

            xx(ii,:)=[xx1(ii) xx2(ii) xx3(ii) xx4(ii)];
            S(ii,:)=1-sol(1:4).*tanh(xx(ii,:));
            s1(ii,:)=[S(ii,:) x5(ii) x6(ii)];
            for i=1:6
                for j=1:10
                    H(j,:)=1./(1+exp(-((alpha_p(i,j).*s1(i))+alpha_p1(j))));
                    gamma_p1=rand;
                    P_=(H(j)*gamma_p(j))+(gamma_p1);
                end
            end
            P(ii)=P_;
        end
        %%reactive power
        alpha_Q(1,:)=sol(85:94);
        alpha_Q(2,:)=sol(95:104);
        alpha_Q(3,:)=sol(105:114);
        alpha_Q(4,:)=sol(115:124);
        alpha_Q(5,:)=sol(125:134);
        alpha_Q(6,:)=sol(135:144);
        alpha_Q1=sol(145:154)';
        gamma_Q=sol(155:164)';
        %% reactive power
        FVector1=FVector1{1, lp};
        target1=target1{1, lp};
        for jj=1:length(FVector1)
            x_max=FVector1(:,2);   %% max
            x_1=FVector1(:,1);      %% min
            x_2=FVector1(:,3);      %% mean
            x_3=FVector1(:,4);      %% median
            x_4=FVector1(:,2);      %% max
            x_5=FVector1(:,5);      %% std
            x_6=FVector1(:,6);      %% entropy
            xx_1(jj)=x_1(jj)/x_max(jj);
            xx_2(jj)=x_2(jj)/x_max(jj);
            xx_3(jj)=x_3(jj)/x_max(jj);
            xx_4(jj)=x_4(jj)/x_max(jj);

            x_x(jj,:)=[xx_1(jj) xx_2(jj) xx_3(jj) xx_4(jj)];
            S_(jj,:)=1-sol(1:4).*tanh(x_x(jj,:));
            s_1(jj,:)=[S_(jj,:) x_5(jj) x_6(jj)];
            for a=1:6
                for b=1:10
                    H_1(b,:)=1./(1+exp(-((alpha_Q(a,b).*s_1(a))+alpha_Q1(b))));
                    gamma_Q1=rand;
                    P_1=(H_1(b)*gamma_Q(b))+(gamma_Q1);
                end
            end
            Q(jj)=P_1;
        end
        act1=target;
        act2=target1;
    end
end
end
