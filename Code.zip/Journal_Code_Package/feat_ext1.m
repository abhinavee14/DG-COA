function[]=feat_ext1()
%% real
load d3
load d4
DD1=[d3;d4];
an = 0;                                             % set 1 to recompute
if an == 1
a = length(DD1);
%% Time domain features 
for i=1:a
%% Statistical
 LS(i,:) = Statistic(DD1(i,:));
 %% High Order Statistical
  HS(i,:) = entropyfeture(DD1(i,:));
end
FVector1=abs([LS HS]); 
%  save FVector1 FVector1
end
end
function[a]=Statistic(b)
a(1)=min(b);
a(2)=max(b);
a(3)=mean(b);
a(4)=median(b);
a(5)=std(b);
end

function [n] = entropyfeture(M) 
n(1)=entropy(M);
end
