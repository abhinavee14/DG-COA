function[]=splitdata()
load FVector     %% real data
load FVector1    %% reactive data
load d1
load d2
load d3
load d4
target=[d1;d2];   %% real tar
target=target(:,4);
target1=[d3;d4];  %% reactive tar
target1=target1(:,4);
FVector_50=FVector(1:20000,:);save FVector_50 FVector_50
FVector_60=FVector(1:24000,:);save FVector_60 FVector_60
FVector_70=FVector(1:28000,:);save FVector_70 FVector_70
FVector_80=FVector(1:32000,:);save FVector_80 FVector_80
target_50=target(1:20000,:);save target_50 target_50
target_60=target(1:24000,:);save target_60 target_60
target_70=target(1:28000,:);save target_70 target_70
target_80=target(1:32000,:);save target_80 target_80
FVector1_50=FVector1(1:20000,:);save FVector1_50 FVector1_50
FVector1_60=FVector1(1:24000,:);save FVector1_60 FVector1_60
FVector1_70=FVector1(1:28000,:);save FVector1_70 FVector1_70
FVector1_80=FVector1(1:32000,:);save FVector1_80 FVector1_80
target1_50=target1(1:20000,:);save target1_50 target1_50
target1_60=target1(1:24000,:);save target1_60 target1_60
target1_70=target1(1:28000,:);save target1_70 target1_70
target1_80=target1(1:32000,:);save target1_80 target1_80
end