function[]=plot_result()
% clc;
% close all;
load errR1       %% real load
Ff = errR1(1,:);
Ga = errR1(2,:);
Gwo = errR1(3,:);
Co = errR1(4,:);
Ho = errR1(5,:);
Sboa = errR1(6,:);
Prop = errR1(7,:);


lr=[50,60,70,80];   %%%%learning percentage
name={'MAE','MSE','RMSE','MAPE','MARE','MSRE','RMSRE'};
idd=[1,2,3,4,5,6,7];
for j=1:4
             F_F(j,:)=cell2mat(struct2cell(Ff{j}));
             G_A(j,:)=cell2mat(struct2cell(Ga{j}));
             G_wo(j,:)=cell2mat(struct2cell(Gwo{j}));
             C_O(j,:)=cell2mat(struct2cell(Co{j}));
             H_O(j,:)=cell2mat(struct2cell(Ho{j}));
             SBoa(j,:)=cell2mat(struct2cell(Sboa{j}));
             PRop(j,:)=cell2mat(struct2cell(Prop{j}));
                    
end  
    
for id=1:7
    M = [F_F(:,id),G_A(:,id),G_wo(:,id),C_O(:,id),H_O(:,id),SBoa(:,id),PRop(:,id)];

methods = {'FF','GA','GWO','COA','HO','SBOA','PROP'};
cols = [0 0.6 0; 0 0 1; 1 0 0; 1 0 1; 0 0.75 0.75; 0 0 0; 0.85 0.33 0.10];

figure('Color','w','Units','centimeters','Position',[2 2 18 11]);
ax = axes; hold on; grid on; box on;

b = bar(lr, M, 'grouped', 'BarWidth', 0.9);   % rows = learning %, columns = methods
for k = 1:7
    b(k).FaceColor = cols(k,:);
    b(k).DisplayName = methods{k};
end

set(ax,'FontName','Times New Roman','FontSize',12,'LineWidth',1, ...
       'XTick',[50 60 70 80]);
xlabel('Learning percentage','fontsize',12);
ylabel(name{id},'fontsize',12);
legend('Location','northoutside','Orientation','horizontal', ...
       'NumColumns',7,'FontSize',11,'Box','off');

print('-dtiff','-r300',['./Journal_Results_26\Real load\',name{id}]);
        % M = [F_F(:,id),G_A(:,id),G_wo(:,id),C_O(:,id),H_O(:,id),SBoa(:,id),PRop(:,id)];
        % figure
        % subplot(7,1,1)
        % plot(lr,M(:,1),'-g*','Linewidth',2,'markerfacecolor','g','Markersize',10);
        % xlabel('Learning percentage','fontsize',10);
        % ylabel(name{id},'fontsize',10);
        % h=legend('FF');
        % set(h,'fontsize',12,'Location','southeast')
        % xlim([50 80]);
        % xticks([50 60 70 80]);
        % 
        % 
        % subplot(7,1,2)
        % plot(lr,M(:,2),'-b*','Linewidth',2,'markerfacecolor','b','Markersize',10);
        % xlabel('Learning percentage','fontsize',10);
        % ylabel(name{id},'fontsize',10);
        % h=legend('GA');
        % set(h,'fontsize',12,'Location','southeast')
        % xlim([50 80]);
        % xticks([50 60 70 80]);
        % 
        % 
        % subplot(7,1,3)
        % plot(lr,M(:,3),'-r*','Linewidth',2,'markerfacecolor','r','Markersize',10);
        % xlabel('Learning percentage','fontsize',10);
        % ylabel(name{id},'fontsize',10);
        % h=legend('GWO');
        % set(h,'fontsize',12,'Location','southeast')
        % xlim([50 80]);
        % xticks([50 60 70 80]);
        % 
        % 
        % subplot(7,1,4)
        % plot(lr,M(:,4),'-m*','Linewidth',2,'markerfacecolor','m','Markersize',10);
        % xlabel('Learning percentage','fontsize',10);
        % ylabel(name{id},'fontsize',10);
        % h=legend('COA');
        % set(h,'fontsize',12,'Location','southeast')
        % xlim([50 80]);
        % xticks([50 60 70 80]);
        % 
        % 
        % subplot(7,1,5)
        % plot(lr,M(:,5),'-c*','Linewidth',2,'MarkerFaceColor','c','MarkerSize',10);
        % xlabel('Learning percentage','fontsize',10);
        % ylabel(name{id},'fontsize',10);
        % h=legend('HO');
        % set(h,'fontsize',12,'Location','southeast')
        % xlim([50 80]);
        % xticks([50 60 70 80]);
        % 
        % 
        % subplot(7,1,6)
        % plot(lr,M(:,6),'-k*','Linewidth',2,'MarkerFaceColor','k','MarkerSize',10);
        % xlabel('Learning percentage','fontsize',10);
        % ylabel(name{id},'fontsize',10);
        % h=legend('SBOA');
        % set(h,'fontsize',12,'Location','southeast')
        % xlim([50 80]);
        % xticks([50 60 70 80]);
        % 
        % 
        % subplot(7,1,7)
        % plot(lr,M(:,7),'-mo','Linewidth',2,'markerfacecolor','k','Markersize',10);
        % xlabel('Learning percentage','fontsize',10);
        % ylabel(name{id},'fontsize',10);
        % h=legend('PROP');
        % set(h,'fontsize',12,'Location','southeast')
        % xlim([50 80]);
        % xticks([50 60 70 80]);
        % print('-dtiff','-r300',['./Journal_Results_26\Real load\',name{id}]);
end
     %% learning percentage
for j=1
        FF=F_F(j,:)';
        GA=G_A(j,:)';
        GWO=G_wo(j,:)';
        COA=C_O(j,:)';
        HO=H_O(j,:)';
        SBOA=SBoa(j,:)';
        PROP=PRop(j,:)';
    end
% %     Table
    disp('lp=50')
    ln = {'MAE','MSE','RMSE','MAPE','MARE','MSRE','RMSRE'};
     T = table(FF(idd),GA(idd),GWO(idd),COA(idd),HO(idd),SBOA(idd),PROP(idd),'RowNames',ln);
    T.Properties.VariableNames = {'FF','GA','GWO','COA','HO','SBOA','PROP'};
    disp(T);
    
    for j=2
        FF=F_F(j,:)';
        GA=G_A(j,:)';
        GWO=G_wo(j,:)';
        COA=C_O(j,:)';
        HO=H_O(j,:)';
        SBOA=SBoa(j,:)';
        PROP=PRop(j,:)';
    end
% %     Table
    disp('lp=60')
    ln = {'MAE','MSE','RMSE','MAPE','MARE','MSRE','RMSRE'};
     T = table(FF(idd),GA(idd),GWO(idd),COA(idd),HO(idd),SBOA(idd),PROP(idd),'RowNames',ln);
    T.Properties.VariableNames = {'FF','GA','GWO','COA','HO','SBOA','PROP'};
    disp(T);

    for j=3
        FF=F_F(j,:)';
        GA=G_A(j,:)';
        GWO=G_wo(j,:)';
        COA=C_O(j,:)';
        HO=H_O(j,:)';
        SBOA=SBoa(j,:)';
        PROP=PRop(j,:)';
    end
% %     Table
    disp('lp=70')
    ln = {'MAE','MSE','RMSE','MAPE','MARE','MSRE','RMSRE'};
     T = table(FF(idd),GA(idd),GWO(idd),COA(idd),HO(idd),SBOA(idd),PROP(idd),'RowNames',ln);
    T.Properties.VariableNames = {'FF','GA','GWO','COA','HO','SBOA','PROP'};
    disp(T);

    for j=4
        FF=F_F(j,:)';
        GA=G_A(j,:)';
        GWO=G_wo(j,:)';
        COA=C_O(j,:)';
        HO=H_O(j,:)';
        SBOA=SBoa(j,:)';
        PROP=PRop(j,:)';
    end
% %     Table
    disp('lp=80')
    ln = {'MAE','MSE','RMSE','MAPE','MARE','MSRE','RMSRE'};
     T = table(FF(idd),GA(idd),GWO(idd),COA(idd),HO(idd),SBOA(idd),PROP(idd),'RowNames',ln);
    T.Properties.VariableNames = {'FF','GA','GWO','COA','HO','SBOA','PROP'};
    disp(T);
    
end