function [bestfit,fitness,bestsol,time] = HO(initsol,fname,xmin,xmax,itermax)
% Hippopotamus Optimization Algorithm (Amiri et al., Sci. Rep., 2024).
% Interface identical to firefly/PSO/GWO.
% Objective evaluations: N + 4N per iteration (3 phases + 1 predator evaluation per hippo).
tic
[N,D] = size(initsol);
lb = xmin(1,:);  ub = xmax(1,:);
X = min(max(initsol,lb),ub);
fit = zeros(N,1);
for i = 1:N, fit(i) = feval(fname,X(i,:)); end
[bestfit,ib] = min(fit);  bestsol = X(ib,:);
fitness = zeros(1,itermax);
half = floor(N/2);
for t = 1:itermax
    Dom = bestsol;                                     % dominant hippopotamus
    Tt  = exp(-t/itermax);
    %% Phase 1: position update in river / pond (exploration)
    for i = 1:N
        I1 = randi(2); I2 = randi(2); Ip = randi([0 1],1,2);
        grp = randperm(N,randi(N));
        MG  = mean(X(grp,:),1);                        % random group mean
        Al  = {I2*rand(1,D)+double(~Ip(1)), 2*rand(1,D)-1, rand(1,D), ...
               I1*rand(1,D)+double(~Ip(2)), rand};
        A = Al{randi(5)};  B = Al{randi(5)};
        if i <= half                                   % male hippopotamus
            Xn = X(i,:) + rand*(Dom - I1*X(i,:));
        else                                           % female / immature
            if Tt > 0.6
                Xn = X(i,:) + A.*(Dom - I2*MG);
            elseif rand > 0.5
                Xn = X(i,:) + B.*(MG - Dom);
            else
                Xn = lb + rand(1,D).*(ub - lb);
            end
        end
        Xn = min(max(Xn,lb),ub);
        fn = feval(fname,Xn);
        if fn < fit(i), X(i,:) = Xn; fit(i) = fn; end
    end
    %% Phase 2: defence against predators (exploration)
    for i = 1:N
        pred  = lb + rand(1,D).*(ub - lb);
        fpred = feval(fname,pred);
        Dd = abs(pred - X(i,:)) + eps;
        RL = 0.05*levy_step(D,1.5);
        b = 2 + 2*rand(1,D);  c = 1 + 0.5*rand(1,D);
        d = 2 + rand(1,D);    g = 2*rand(1,D) - 1;
        if fpred < fit(i)
            Xn = RL.*pred + (b./(c - d.*cos(2*pi*g))).*(1./Dd);
        else
            Xn = RL.*pred + (b./(c - d.*cos(2*pi*g))).*(1./(2*Dd + rand(1,D)));
        end
        Xn = min(max(Xn,lb),ub);
        fn = feval(fname,Xn);
        if fn < fit(i), X(i,:) = Xn; fit(i) = fn; end
    end
    %% Phase 3: escape from predator (exploitation)
    lbl = lb/t;  ubl = ub/t;
    for i = 1:N
        S  = {2*rand(1,D)-1, rand, randn};
        s  = S{randi(3)};
        Xn = X(i,:) + rand*(lbl + s.*(ubl - lbl));
        Xn = min(max(Xn,lb),ub);
        fn = feval(fname,Xn);
        if fn < fit(i), X(i,:) = Xn; fit(i) = fn; end
    end
    [m,ib] = min(fit);
    if m < bestfit, bestfit = m; bestsol = X(ib,:); end
    fitness(t) = bestfit;
end
time = toc;
end

function s = levy_step(D,beta)
sigma = (gamma(1+beta)*sin(pi*beta/2)/(gamma((1+beta)/2)*beta*2^((beta-1)/2)))^(1/beta);
u = randn(1,D)*sigma;  v = randn(1,D);
s = u./abs(v).^(1/beta);
end