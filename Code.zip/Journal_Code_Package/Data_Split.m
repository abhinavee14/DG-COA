% Total number of datasets
totalDatasets = 100;

% Training percentages
trainingPercentages = [50 60 70 80];

% Calculate training and testing counts
trainingCount = round(totalDatasets * trainingPercentages / 100);
testingCount = totalDatasets - trainingCount;

% Display results
SplitResults = table(trainingPercentages', trainingCount', ...
    testingCount', 'VariableNames', ...
    {'Training_Percentage', 'Training_Count', 'Testing_Count'});

disp(SplitResults);