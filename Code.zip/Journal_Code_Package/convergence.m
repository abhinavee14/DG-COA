function[]=convergence()
load ff
load Ga
load Gw
load co
load hoa
load sboa
load prop
figure
plot(ff.fit,'r','Linewidth',2);hold on
plot(Ga.fit,'g','Linewidth',2);
plot(Gw.fit,'b','Linewidth',2);
plot(co.fit,'c','Linewidth',2);
plot(hoa.fit,'Color',[0.85 0.33 0.10],'LineWidth',2);
plot(sboa.fit,'k','Linewidth',2);
plot(prop.fit,'m','Linewidth',2);
h=legend('FF','GA','GWO','COA','HOA','SBOA','PROP');
set(h,'fontsize',12,'Location','best')
ylabel('Fitness')
xlabel('Iteration')
set(gca,'fontsize',14)
  print('-dtiff','-r300',['.\Journal_Results_26\', 'Convergence'])
  a = ff.fit(:);
  b = Ga.fit(:);
  c = Gw.fit(:);
  d = co.fit(:);
  e = hoa.fit(:);
  f = sboa.fit(:);
  g = prop.fit(:);
  figure
format long
boxplot([a,b,c,d,e,f,g])
set(gca,'fontsize',16)
    xticklabels({'FF','GA','GWO','COA','HOA','SBOA','PROP'})
    xtickangle(90)
    ylabel('Fitness','fontsize',16)
    title('Convergence Analysis')
    print('-dtiff','-r300',['.\Journal_Results_26\', 'convg-box'])

 disp('statistical Analysis')
    s1 = stats(ff.fit);
    s2 = stats(Ga.fit);
    s3 = stats(Gw.fit);
    s4 = stats(co.fit);
    s5 = stats(hoa.fit);
    s6 = stats(sboa.fit);
    s7 = stats(prop.fit);
    disp(table(s1',s2',s3',s4',s5',s6',s7', ...
        'VariableNames',{'FF','GA','GWO','COA','HOA','SBOA','PROP'}, ...
        'RowNames',{'Best','Worst','Mean','Median','STD'}))
%   %% convergence subplot 
% figure
% subplot(5,1,1)
% plot(ff.fit,'r','LineWidth',2);
% ylabel('Fitness');
% xlabel('Iteration');
% h=legend('FF');
% set(h,'fontsize',12,'Location','best')
% axis tight
% 
% subplot(5,1,2)
% plot(Ga.fit,'g','Linewidth',2);
% ylabel('Fitness');
% xlabel('Iteration')
% h=legend('GA');
% set(h,'fontsize',12,'Location','best')
% axis tight
% 
% subplot(5,1,3)
% plot(Gw.fit,'b','Linewidth',2);
% ylabel('Fitness');
% xlabel('Iteration')
% h=legend('GWO');
% set(h,'fontsize',12,'Location','best')
% axis tight
% 
% subplot(5,1,4)
% plot(co.fit,'c','Linewidth',2);
% ylabel('Fitness');
% xlabel('Iteration')
% h=legend('COA');
% set(h,'fontsize',12,'Location','best')
% axis tight
%
% subplot(5,1,5)
% plot(hoa.fit,'y','Linewidth',2);
% ylabel('Fitness');
% xlabel('Iteration')
% h=legend('HOA');
% set(h,'fontsize',12,'Location','best')
% axis tight
%
% subplot(5,1,6)
% plot(sboa.fit,'k','Linewidth',2);
% ylabel('Fitness');
% xlabel('Iteration')
% h=legend('SBOA');
% set(h,'fontsize',12,'Location','best')
% axis tight
% 
% subplot(5,1,7)
% plot(prop.fit,'m','Linewidth',2);
% ylabel('Fitness');
% xlabel('Iteration')
% h=legend('PROP');
% set(h,'fontsize',12,'Location','best')
% axis tight
%   print('-dtiff','-r300',['.\Journal_Results_26\', 'convergence_sub'])
end
function[b] = stats(a)
b(1) = min(a);
b(2) = max(a);
b(3) = mean(a);
b(4) = median(a);
b(5) = std(a);
end