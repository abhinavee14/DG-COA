function[]=Journal_Analysis_zipdata_57b()
clc
%% Zip data
global ts_data_r ts_tar_r ts_data_rc ts_tar_rc
load ff_J
load Ga_J
load Gw_J
load co_J
load prop_J
soln(1,:)=ff_J.bs;
soln(2,:)=Ga_J.bs{1, 30};
soln(3,:)=Gw_J.bs;
soln(4,:)=co_J.bs;
soln(5,:)=prop_J.bs;
bs = soln;
lp=[60 70 80];
load FVector_zipreal_57b
load D_zipreal_57b

load FVector_zipreact_57b
load D_zipreact_57b

DATA_real.IN=FVector_zipreal_57b;
DATA_real.TAR=D_zipreal_57b;
        dtar_real=(DATA_real.TAR(:,4)-min(DATA_real.TAR(:,4)))/(max(DATA_real.TAR(:,4))-min(DATA_real.TAR(:,4)));

for i=1:size(DATA_real.IN,2)
        din_real(:,i)=(DATA_real.IN(:,i)-min(DATA_real.IN(:,i)))/(max(DATA_real.IN(:,i))-min(DATA_real.IN(:,i)));

end
DATA_real.IN=din_real;
DATA_real.TAR=dtar_real;

DATA_react.IN=FVector_zipreact_57b;
DATA_react.TAR=D_zipreact_57b;

dtar_react=(DATA_react.TAR(:,4)-min(DATA_react.TAR(:,4)))/(max(DATA_react.TAR(:,4))-min(DATA_react.TAR(:,4)));

for i=1:size(DATA_real.IN,2)
        din_react(:,i)=(DATA_react.IN(:,i)-min(DATA_react.IN(:,i)))/(max(DATA_react.IN(:,i))-min(DATA_react.IN(:,i)));

end

DATA_react.IN=din_react;
DATA_react.TAR=dtar_react;
for l=1:length(lp)
    for alg=1:size(bs,1)
[tr_data_r,tr_tar_r,ts_data_r,ts_tar_r] = split_data(DATA_real,lp(l));
[tr_data_rc,tr_tar_rc,ts_data_rc,ts_tar_rc] = split_data(DATA_react,lp(l));
[P,Q,Act_P,Act_Q] = Objfun_zip(bs(alg,:));
ResJ_zip_57b{l,alg}.realP=P;
ResJ_zip_57b{l,alg}.reactQ=Q;
ResJ_zip_57b{l,alg}.actP=Act_P;
ResJ_zip_57b{l,alg}.actQ=Act_Q;
    ResJ_zip_57b{l,alg}.err1=Error(ResJ_zip_57b{l,alg}.realP,ResJ_zip_57b{l,alg}.actP');
    ResJ_zip_57b{l,alg}.err2=Error(ResJ_zip_57b{l,alg}.reactQ,ResJ_zip_57b{l,alg}.actQ');
    end
end
save ResJ_zip_57b ResJ_zip_57b
end
function[P,Q,Act_P,Act_Q] = Objfun_zip(soln)
global ts_data_r ts_tar_r ts_data_rc ts_tar_rc
%% for Real zip data
for k=1:size(soln,1)
sol = soln(k,:);
%% real power
alpha_p(1,:)=sol(5:14);
alpha_p(2,:)=sol(15:24);
alpha_p(3,:)=sol(25:34);
alpha_p(4,:)=sol(35:44);
alpha_p(5,:)=sol(45:54);
alpha_p(6,:)=sol(55:64);
alpha_p1=sol(65:74)';
gamma_p=sol(75:84)';
for ii=1:length(ts_data_r)
    xmax=ts_data_r(:,2);   %% max
    x1=ts_data_r(:,1);      %% min
    x2=ts_data_r(:,3);      %% mean
    x3=ts_data_r(:,4);      %% median
    x4=ts_data_r(:,2);      %% max
    x5=ts_data_r(:,5);      %% std
    % x6=FVector(:,6);      %% entropy
    xx1(ii)=x1(ii)/xmax(ii);
    xx2(ii)=x2(ii)/xmax(ii);
    xx3(ii)=x3(ii)/xmax(ii);
    xx4(ii)=x4(ii)/xmax(ii);
            
xx(ii,:)=[xx1(ii) xx2(ii) xx3(ii) xx4(ii)];
S(ii,:)=1-sol(1:4).*tanh(xx(ii,:));
s1(ii,:)=[S(ii,:) x5(ii)];
for i=1:5
    for j=1:10
H(j,:)=1./(1+exp(-((alpha_p(i,j).*s1(i))+alpha_p1(j))));
gamma_p1=rand;
P_=(H(j)*gamma_p(j))+(gamma_p1);
    end
end
P(ii)=P_;
end
%% reactive power
alpha_Q(1,:)=sol(85:94);
alpha_Q(2,:)=sol(95:104);
alpha_Q(3,:)=sol(105:114);
alpha_Q(4,:)=sol(115:124);
alpha_Q(5,:)=sol(125:134);
alpha_Q(6,:)=sol(135:144);
alpha_Q1=sol(145:154)';
gamma_Q=sol(155:164)';
for jj=1:length(ts_data_rc)
    x_max=ts_data_rc(:,2);   %% max
    x_1=ts_data_rc(:,1);      %% min
    x_2=ts_data_rc(:,3);      %% mean
    x_3=ts_data_rc(:,4);      %% median
    x_4=ts_data_rc(:,2);      %% max
    x_5=ts_data_rc(:,5);      %% std
    % x_6=FVector_zipreact(:,6);      %% entropy
    xx_1(jj)=x_1(jj)/x_max(jj);
    xx_2(jj)=x_2(jj)/x_max(jj);
    xx_3(jj)=x_3(jj)/x_max(jj);
    xx_4(jj)=x_4(jj)/x_max(jj);
            
x_x(jj,:)=[xx_1(jj) xx_2(jj) xx_3(jj) xx_4(jj)];
S_(jj,:)=1-sol(1:4).*tanh(x_x(jj,:));
s_1(jj,:)=[S_(jj,:) x_5(jj)];
for a=1:5
    for b=1:10
H_1(b,:)=1./(1+exp(-((alpha_Q(a,b).*s_1(a))+alpha_Q1(b))));
gamma_Q1=rand;
P_1=(H_1(b)*gamma_Q(b))+(gamma_Q1);
    end
end
Q(jj)=P_1;
end
Act_P=ts_tar_r;
Act_Q=ts_tar_rc;
end
end

