function [GlobalMin,conv,GlobalParams,ct] = Adap_COA(coyotes,FOBJ, LB,UB, nfevalMAX)
% [~,D] = size(~);
GlobalMin=inf;
n_packs          = 20;                    % Number of packs
n_coy          = 5;                     % Number of coyotes
conv=zeros(1,nfevalMAX);
conv(1)= inf;
% Example:
% FOBJ        = @(x) sum(x.^2);         % Optimization problem
% D           = 30;                     % Problem dimension
% lu          = [zeros(1,D);ones(1,D)]; % Seach space
% nfevalMAX   = 10000*D;                % Stopping criteria
% Np          = 10;                     % Number of packs
% Nc          = 10;                     % Number of coyotes
% [GlobalParams,GlobalMin] = COA(FOBJ, lu, nfevalMAX,Np,Nc);%% ------------------------------------------------------------------------

%% Optimization problem variables

 D= size(LB,2);
LB=LB(1,:);
UB=UB(1,:);

%% Algorithm parameters
if nargin < 5, n_coy = 5; 
elseif n_coy < 3, error('At least 3 coyotes per pack!'); end
if nargin < 4, n_packs = 20; end

% Probability of leaving a pack
p_leave     = 0.005*n_coy^2;
Ps          = 1/D;
tic;
%% Packs initialization (Eq. 2)
  pop_total   = n_packs*n_coy;
 costs       = zeros(pop_total,1);
coyotes     = repmat(LB,pop_total,1) + rand(pop_total,D).*(repmat(UB,pop_total,1) - repmat(LB,pop_total,1));
ages        = zeros(pop_total,1);
packs       = reshape(randperm(pop_total),n_packs,[]);
coypack     = repmat(n_coy,n_packs,1);

%% Evaluate coyotes adaptation (Eq. 3)
for c=1:pop_total
    costs(c,1) = feval(FOBJ,(coyotes(c,:)));
%     if costs(c)<GlobalMin
%             GlobalMin=costs(1,c);
% %             Best_P=X(c,:);
%         end
end
nfeval = pop_total;

%% Output variables
[GlobalMin,ibest]   = min(costs);
GlobalParams        = coyotes(ibest,:); 
    
%% Main loop
year=0;
%while nfeval<nfevalMAX % Stopping criteria
   for i=1:nfevalMAX
    %% Update the years counter
    year = year + 1;

    %% Execute the operations inside each pack
    for p=1:n_packs
        % Get the coyotes that belong to each pack
        coyotes_aux = coyotes(packs(p,:),:);
        costs_aux   = costs(packs(p,:),:);
        ages_aux    = ages(packs(p,:),1);
        n_coy_aux   = coypack(p,1);
        
        % Detect alphas according to the costs (Eq. 5)
        [costs_aux,inds] = sort(costs_aux,'ascend');
        coyotes_aux      = coyotes_aux(inds,:);
        ages_aux         = ages_aux(inds,:);
        c_alpha          = coyotes_aux(1,:);
        
        % Compute the social tendency of the pack (Eq. 6)
        tendency         = median(coyotes_aux,1);
        
        % Update coyotes' social condition
        new_coyotes      = zeros(n_coy_aux,D);
        for c=1:n_coy_aux
            rc1 = c;
            while rc1==c
                rc1 = randi(n_coy_aux);
            end
            rc2 = c;
            while rc2==c || rc2 == rc1
                rc2 = randi(n_coy_aux);
            end
            new_c = coyotes_aux(c,:) + rand*(c_alpha - coyotes_aux(rc1,:))+ ...
                                       rand*(tendency  - coyotes_aux(rc2,:));
            j3=3;      %% random initialization
            if p==j3
                s_coyotes_aux(c,:)=coyotes_aux(c,:)+rand*(c_alpha - coyotes_aux(rc1,:))+ ...
                                       rand*(tendency  - coyotes_aux(rc2,:));
            else
                s_coyotes_aux(c,:)=new_c;
            end
            omega=0.5;
            if rand<omega
               new_c=coyotes_aux(c,:) + rand*(c_alpha - coyotes_aux(rc1,:))+ ...
                                       rand*(tendency  - coyotes_aux(rc2,:))+levy(1,1,1.5);
            else
               new_c= s_coyotes_aux(c,:);
            % Try to update the social condition according to the alpha and
            % the pack tendency (Eq. 12)
            
            
            % Keep the coyotes in the search space (optimization problem
            % constraint)
             new_coyotes(c,:) = min(max(new_c,LB),UB);
            
            % Evaluate the new social condition (Eq. 13)
            new_cost = feval(FOBJ,(new_coyotes(c,:)));
            nfeval   = nfeval+1;
            
            % Adaptation (Eq. 14)
            if new_cost < costs_aux(c,1)
                costs_aux(c,1)      = new_cost;
                coyotes_aux(c,:)    = new_coyotes(c,:);
            end
        end
        
        %% Birth of a new coyote from random parents (Eq. 7 and Alg. 1)
        parents         = randperm(n_coy_aux,2);
        prob1           = (1-Ps)/2;
        prob2           = prob1;
        pdr             = randperm(D);
        p1              = zeros(1,D);
        p2              = zeros(1,D);
        p1(pdr(1))      = 1; % Guarantee 1 charac. per individual
        p2(pdr(2))      = 1; % Guarantee 1 charac. per individual
        r               = rand(1,D-2);
        p1(pdr(3:end))  = r < prob1;
        p2(pdr(3:end))  = r > 1-prob2;
        
        % Eventual noise 
        n  = ~(p1|p2);
        
        % Generate the pup considering intrinsic and extrinsic influence
        pup =   p1.*coyotes_aux(parents(1),:) + ...
                p2.*coyotes_aux(parents(2),:) + ...
                n.*(LB + rand(1,D).*(UB-LB));
        
        % Verify if the pup will survive
        pup_cost    = feval(FOBJ,pup);
        nfeval      = nfeval + 1;
        worst       = find(pup_cost<costs_aux==1);
        if ~isempty(worst)
            [~,older]               = sort(ages_aux(worst),'descend');
            which                   = worst(older);
            coyotes_aux(which(1),:) = pup(1);
            costs_aux(which(1),1)   = pup_cost;
            ages_aux(which(1),1)    = 0;
        end
        
        %% Update the pack information
        coyotes(packs(p,:),:) = coyotes_aux;
        costs(packs(p,:),:)   = costs_aux;
        ages(packs(p,:),1)    = ages_aux;
    end
    
    %% A coyote can leave a pack and enter in another pack (Eq. 4)
    if n_packs>1
        if rand < p_leave
            rp                  = randperm(n_packs,2);
            rc                  = randi(n_coy,1,2);
            aux                 = packs(rp(1),rc(1));
            packs(rp(1),rc(1))  = packs(rp(2),rc(2));
            packs(rp(2),rc(2))  = aux;
        end
    end
   
    %% Update coyotes ages
    ages = ages + 1;
    
    %% Output variables (best alpha coyote among all alphas)
    [GlobalMin,ibest]   = min(costs);
    GlobalParams        = coyotes(ibest,:);
    conv=costs(1:nfevalMAX);
    conv=sortrows(conv,'descend');
    if GlobalMin<conv(nfevalMAX)
        conv(nfevalMAX)=GlobalMin;
        %             Best_P=X(i,:);
    else
        conv(nfevalMAX)=conv(end);
    end
%     conv(nfeval)=costs;
end
 ct= toc;
end
