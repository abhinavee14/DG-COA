clc;
clear;
close all;

%% 1. Load statistics from MAT files
load('ffstats.mat');
load('Gastats.mat');
load('Gwstats.mat');
load('Costats.mat');
load('hoastats.mat');
load('sboastats.mat');
load('propstats.mat');

%% 2. Combine loaded statistics
% Ensure each MAT file contains the expected variable.
stats = [
    ffstats(:)';
    Gastats(:)';
    Gwstats(:)';
    Costats(:)';
    hoastats(:)';
    sboastats(:)';
    propstats(:)'
];

methodNames = {'FF','GA','GW','CO','HOA','SBOA','PROP'};

%% 3. Validate data
if any(~isfinite(stats(:)))
    error('Loaded statistics contain NaN or Inf values.');
end

if size(stats,2) < 2
    error('At least two observations per method are required.');
end

if any(sum(isfinite(stats),2) ~= size(stats,2))
    error('All methods must have the same number of observations.');
end

%% 4. Calculate mean, standard deviation and 95% CI
alpha = 0.05;
n = size(stats, 2);
tcrit = tinv(1 - alpha/2, n - 1);

MeanValues = zeros(size(stats,1),1);
StdValues  = zeros(size(stats,1),1);
LowerCI    = zeros(size(stats,1),1);
UpperCI    = zeros(size(stats,1),1);

fprintf('\n95%% Confidence Intervals\n');
fprintf('-----------------------------------------------\n');

for i = 1:size(stats,1)

    x = stats(i,:);

    mu = mean(x);
    s = std(x,0,2);
    margin = tcrit * s / sqrt(n);

    CI_lower = mu - margin;
    CI_upper = mu + margin;

    MeanValues(i) = mu;
    StdValues(i) = s;
    LowerCI(i) = CI_lower;
    UpperCI(i) = CI_upper;

    fprintf('%s: Mean = %.6f, SD = %.6f, ', ...
        methodNames{i}, mu, s);
    fprintf('95%% CI = [%.6f, %.6f]\n', ...
        CI_lower, CI_upper);
end

%% 5. Display results in a table
Results = table(MeanValues, StdValues, LowerCI, UpperCI, ...
    'RowNames', methodNames, ...
    'VariableNames', {'Mean','SD','Lower95CI','Upper95CI'});

disp(Results);

%% 6. Plot confidence intervals
figure;

errorbar(1:numel(methodNames), MeanValues, ...
    MeanValues-LowerCI, UpperCI-MeanValues, ...
    'o', 'LineWidth', 1.5, 'MarkerSize', 7);

set(gca, 'XTick', 1:numel(methodNames), ...
    'XTickLabel', methodNames);

xlabel('Optimization Algorithm');
ylabel('Mean Convergence Value');
title('Mean Values with 95% Confidence Intervals');
grid on;
xlim([0.5, numel(methodNames)+0.5]);

%% 7. Save results
writetable(Results, 'Confidence_Interval_Results.csv', ...
    'WriteRowNames', true);

save('Confidence_Interval_Results.mat', 'Results');

fprintf('\nResults saved successfully.\n');
