function [bfit,fbest,nbest,time,metrics] = firefly_metrics(val,obj,L,U,itermax)
% Same outputs as before, plus an optional 5th output "metrics" (struct)
% holding complexity, wall time, CPU time and memory figures.
% Existing calls with 4 outputs still work unchanged.
[N,D] = size(val);
% parameters [n N_iteration alpha betamin gamma]
para=[N itermax 0.5 0.2 1];
Lb=L(1,:);
Ub=U(1,:);
u0 = val;

[nbest,bfit,fbest,time,metrics]=ffa_mincon(D,u0,Lb,Ub,para,obj);
end

function [nbest,bfit,fbest,time,metrics] = ffa_mincon(d,u0,Lb,Ub,para,obj)
n=para(1);  MaxGeneration=para(2);
alpha=para(3); betamin=para(4); gamma=para(5);

if length(Lb) ~= length(Ub)
    disp('Simple bounds/limits are improper!');
    return
end

ns = u0;

% ---------------- measurement set-up ----------------
memTrace  = zeros(MaxGeneration+1,1);   % memory sampled each iteration (bytes)
nDistTot  = 0;                          % pairwise distance computations
nMoveTot  = 0;                          % actual firefly moves
nEvalTot  = 0;                          % objective-function evaluations (per solution)
memTrace(1) = mem_used_bytes();
cpu0  = cputime;                        % CPU time (process, all threads)
tic;                                    % wall-clock (execution) time
% -----------------------------------------------------

fbest = zeros(1,MaxGeneration);
for k=1:MaxGeneration
    alpha=alpha_new(alpha,MaxGeneration);

    zn = feval(obj,ns);
    nEvalTot = nEvalTot + n;

    [Lightn,Index]=sort(zn);
    ns_tmp=ns;
    for i=1:n
        ns(i,:)=ns_tmp(Index(i),:);
    end

    nso=ns; Lighto=Lightn;
    nbest=ns(1,:); Lightbest=Lightn(1);

    fbest(k) = Lightbest;

    [ns,nDist,nMove]=ffa_move(n,d,ns,Lightn,nso,Lighto,nbest,...
          Lightbest,alpha,betamin,gamma,Lb,Ub);
    nDistTot = nDistTot + nDist;
    nMoveTot = nMoveTot + nMove;

    memTrace(k+1) = mem_used_bytes();
end

time    = toc;                  % wall-clock execution time (s)
cpuTime = cputime - cpu0;       % CPU time (s)
fbest   = sort(fbest,'descend');
bfit    = fbest(end);

% ---------------- collect metrics ----------------
metrics.exec_time_s = time;
metrics.cpu_time_s  = cpuTime;

% Memory
metrics.mem_start_MB = memTrace(1)/2^20;
metrics.mem_peak_MB  = max(memTrace)/2^20;
metrics.mem_increase_MB = (max(memTrace)-memTrace(1))/2^20;
w = whos('ns','nso','ns_tmp','zn','Lightn','Lighto','fbest','memTrace');
metrics.algo_variables_MB = sum([w.bytes])/2^20;   % memory of the algorithm's own arrays

% Computational complexity
% Theoretical: sort O(n log n) + movement O(n^2 d) + evaluation O(n*C_f), per iteration
metrics.complexity_theory = 'O(T * (n^2 * d + n*log(n) + n*C_f))';
metrics.space_complexity  = 'O(n * d)';
metrics.n = n; metrics.d = d; metrics.T = MaxGeneration;
% Empirical operation counts
metrics.n_distance_computations = nDistTot;   % ~ T*n^2
metrics.n_moves                 = nMoveTot;
metrics.n_function_evals        = nEvalTot;   % = T*n
metrics.approx_flops_move       = nDistTot*(3*d) + nMoveTot*(6*d);   % rough estimate

fprintf('\n=== Firefly performance ===\n');
fprintf('Complexity (time)  : %s\n', metrics.complexity_theory);
fprintf('Complexity (space) : %s\n', metrics.space_complexity);
fprintf('n=%d, d=%d, T=%d | distance calcs=%d, moves=%d, f-evals=%d\n', ...
    n,d,MaxGeneration,nDistTot,nMoveTot,nEvalTot);
fprintf('Execution time     : %.4f s\n', metrics.exec_time_s);
fprintf('CPU time           : %.4f s\n', metrics.cpu_time_s);
fprintf('Peak memory        : %.2f MB (increase %.2f MB)\n', ...
    metrics.mem_peak_MB, metrics.mem_increase_MB);
fprintf('Algorithm arrays   : %.4f MB\n\n', metrics.algo_variables_MB);
end

% ---- memory helper: MATLAB used memory in bytes ----
function b = mem_used_bytes()
b = NaN;
try
    m = memory;                       % Windows only
    b = m.MemUsedMATLAB;
catch
    try
        [~,out] = system(sprintf('ps -o rss= -p %d', feature('getpid')));   % Linux/macOS
        b = str2double(out)*1024;
    catch
        w = evalin('base','whos'); b = sum([w.bytes]);   % fallback
    end
end
end

% Move all fireflies toward brighter ones
function [ns,nDist,nMove]=ffa_move(n,d,ns,Lightn,nso,Lighto,...
             nbest,Lightbest,alpha,betamin,gamma,Lb,Ub)
scale=abs(Ub-Lb);
nDist = 0; nMove = 0;
for i=1:n
   for j=1:n
      r=sqrt(sum((ns(i,:)-ns(j,:)).^2));
      nDist = nDist + 1;
      if Lightn(i)>Lighto(j)
         beta0=1; beta=(beta0-betamin)*exp(-gamma*r.^2)+betamin;
         tmpf=alpha.*(rand(1,d)-0.5).*scale;
         ns(i,:)=ns(i,:).*(1-beta)+nso(j,:).*beta+tmpf;
         nMove = nMove + 1;
      end
   end
end
[ns]=findlimits(n,ns,Lb,Ub);
end

function alpha=alpha_new(alpha,NGen)
delta=1-(10^(-4)/0.9)^(1/NGen);
alpha=(1-delta)*alpha;
end

function [ns]=findlimits(n,ns,Lb,Ub)
for i=1:n
  ns_tmp=ns(i,:);
  I=ns_tmp<Lb;
  ns_tmp(I)=Lb(I);
  J=ns_tmp>Ub;
  ns_tmp(J)=Ub(J);
  ns(i,:)=ns_tmp;
end
end