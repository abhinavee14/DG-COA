function[]=normaliz()
%% real power sag and swell
load input_F1 
load input_F2 
load output_F1 
load output_F2 
d_1=[input_F1 output_F1];
d_2=[input_F2 output_F2];
an = 0;                                             % set 1 to recompute
if an == 1
i=1;
for i=1:4
    d1(:,i)=(d_1(:,i)-min(d_1(:,i)))/(max(d_1(:,i))-min(d_1(:,i)));
    d2(:,i)=(d_2(:,i)-min(d_2(:,i)))/(max(d_2(:,i))-min(d_2(:,i)));
end
i=i+1;
% save d1 d1;save d2 d2;

%% reactive power sag and swell
load input_F11 
load input_F21
load output_F11
load output_F21 
d_3=[input_F11 output_F11];
d_4=[input_F21 output_F21];

i=1;
for i=1:4
    d3(:,i)=(d_3(:,i)-min(d_3(:,i)))/(max(d_3(:,i))-min(d_3(:,i)));
    d4(:,i)=(d_4(:,i)-min(d_4(:,i)))/(max(d_4(:,i))-min(d_4(:,i)));
end
i=i+1;
% save d3 d3;save d4 d4;
end
end