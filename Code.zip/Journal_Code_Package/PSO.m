function [bestfit,fitness,bestsol,time] = PSO(initsol,fname,xmin,xmax,itermax)

disp('Particle Swarm...')

tic

%% Initialization
N = size(initsol,1);
D = size(initsol,2);

X = initsol;

% Boundary checking
X = min(max(X,xmin),xmax);

% PSO parameters
PHI1 = 1.5;
PHI2 = 1.5;
W = 1;

% Velocity
V = zeros(N,D);

% Velocity limits
Vmin = -0.2.*(xmax-xmin);
Vmax =  0.2.*(xmax-xmin);

% Personal best position
Pbest = X;

% Personal best fitness
PbestFitness = inf(N,1);

% Global best
bestfit = inf;
bestsol = zeros(1,D);

% Convergence curve
fitness = zeros(1,itermax);

%% Initial fitness evaluation
for i = 1:N

    fit = feval(fname,X(i,:));

    PbestFitness(i) = fit;
    Pbest(i,:) = X(i,:);

    if fit < bestfit

        bestfit = fit;
        bestsol = X(i,:);

    end

end

%% Main PSO loop
for it = 1:itermax

    disp(['PSO iteration ',num2str(it)])

    % Random numbers
    r1 = rand(N,D);
    r2 = rand(N,D);

    % Velocity update
    V = W.*V ...
        + PHI1.*r1.*(Pbest-X) ...
        + PHI2.*r2.*(bestsol-X);

    % Velocity boundary
    V = max(V,Vmin);
    V = min(V,Vmax);

    % Position update
    X = X + V;

    % Position boundary
    X = min(max(X,xmin),xmax);

    %% Fitness evaluation
    for i = 1:N

        fit = feval(fname,X(i,:));

        % Update personal best
        if fit < PbestFitness(i)

            PbestFitness(i) = fit;
            Pbest(i,:) = X(i,:);

        end

        % Update global best
        if fit < bestfit

            bestfit = fit;
            bestsol = X(i,:);

        end

    end

    % Store convergence curve
    fitness(it) = bestfit;

end

%% Execution time
time = toc;

end