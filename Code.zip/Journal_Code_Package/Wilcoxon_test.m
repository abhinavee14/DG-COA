clc;
clear;
close all;

%% 1. Load data from MAT files
files = {'ffstats.mat', 'Gastats.mat', 'Gwstats.mat', 'Costats.mat', ...
         'hoastats.mat', 'sboastats.mat', 'propstats.mat'};

AlgorithmNames = {'FF', 'GA', 'GW', 'CO', 'HOA', 'SBOA', 'PROP'};

Results = [];

for i = 1:length(files)

    if ~isfile(files{i})
        error('File not found: %s. Check the file path.', files{i});
    end

    S = load(files{i});
    vars = fieldnames(S);

    if isempty(vars)
        error('No variables found in %s.', files{i});
    end

    % Display the variables stored in each file
    fprintf('\nFile: %s\n', files{i});
    disp(vars);

    % Use the first variable stored in the file
    data = S.(vars{1});
    data = data(:);

    if i == 1
        Results = zeros(length(data), length(files));
    elseif length(data) ~= size(Results, 1)
        error('Data length mismatch in %s.', files{i});
    end

    Results(:, i) = data;
end

alpha = 0.05;

%% 2. Wilcoxon rank-sum test
fprintf('\nWILCOXON RANK-SUM TEST\n');

for i = 1:size(Results, 2)-1

    [p, h] = ranksum(Results(:, end), Results(:, i));

    fprintf('PROP vs %s: p-value = %.6f, h = %d\n', ...
        AlgorithmNames{i}, p, h);
end

%% 5. Descriptive statistics
SummaryTable = table(AlgorithmNames', mean(Results)', ...
    std(Results)', median(Results)', ...
    'VariableNames', {'Algorithm', 'Mean', 'StdDev', 'Median'});

fprintf('\nDESCRIPTIVE STATISTICS\n');
disp(SummaryTable);