function[]=feat_ext()
%% real
load d1 
load d2
DD1=[d1;d2];
an = 0;                                             % set 1 to recompute
if an == 1
a = length(DD1);
%% Time domain features 
for i=1:a
%% Statistical
 LS(i,:) = Statistic(DD1(i,:));
 %% High Order Statistical
  HS(i,:) = entropyfeature(DD1(i,:));
end
FVector=abs([LS HS]); 
% save FVector FVector
end
end
function[a]=Statistic(b)
a(1)=min(b);
a(2)=max(b);
a(3)=mean(b);
a(4)=median(b);
a(5)=std(b);
end

function [n] = entropyfeature(M) 
n(1)=entropy(M);
end
