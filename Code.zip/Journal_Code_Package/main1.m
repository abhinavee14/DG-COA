function[] = main1()
clc;
clear all;
close all;
warning off
%% Optimization Initialization
Npop = 10;                            % population size
xmin1 = zeros(Npop,4);                % setting minimum bound for W
xmax1 = ones(Npop,4);                 % setting maximum bound for W
xmin2 = zeros(Npop,60);               % setting minimum bound for alpha_p
xmax2 = ones(Npop,60);                % setting maximum bound for alpha_p
xmin3 = zeros(Npop,10);               % setting minimum bound for alpha_p1
xmax3 = ones(Npop,10);                % setting maximum bound for alpha_p1
xmin4 = zeros(Npop,10);		          % setting minimum bound for gamma_P
xmax4 = ones(Npop,10);                % setting maximum bound for gamma_P
xmin5 = zeros(Npop,60);               % setting minimum bound for alpha_Q
xmax5 = ones(Npop,60);                % setting maximum bound for alpha_Q
xmin6 = zeros(Npop,10);               % setting minimum bound for alpha_Q1
xmax6 = ones(Npop,10);                % setting maximum bound for alpha_Q1
xmin7 = zeros(Npop,10);		          % setting minimum bound for gamma_Q
xmax7 = ones(Npop,10);                % setting maximum bound for gamma_Q
initsol1 = unifrnd(xmin1,xmax1);
initsol2 = unifrnd(xmin2,xmax2);
initsol3 = unifrnd(xmin3,xmax3);
initsol4 = unifrnd(xmin4,xmax4);
initsol5 = unifrnd(xmin5,xmax5);
initsol6 = unifrnd(xmin6,xmax6);
initsol7 = unifrnd(xmin7,xmax7);

xmin = [xmin1 xmin2 xmin3 xmin4 xmin5 xmin6 xmin7];
xmax = [xmax1 xmax2 xmax3 xmax4 xmax5 xmax6 xmax7];
initsol = [initsol1 initsol2 initsol3 initsol4 initsol5 initsol6 initsol7];    % random solution
itermax = 30;                              % iteration

fname = 'Objfun1';                                % function name

%% Algorithm
an = 1;                                             % set 1 to recompute
if an == 1
    
    disp('Firefly....')
    [bestfit,fitness,bestsol,time] = firefly(initsol,fname,xmin,xmax,itermax); 
    ff.bf = bestfit; ff.fit = fitness; ff.bs = bestsol; ff.ct = time;
 % %       save ff ff 

      disp('Genetic...')
    [bestfit,fitness,bestsol,time] = genetic(initsol,fname,xmin,xmax,itermax); 
    Ga.bf = bestfit; Ga.fit = fitness; Ga.bs = bestsol; Ga.ct = time;
% %       save Ga Ga 

    disp('Gray wolf....')
    [bestfit,fitness,bestsol,time] = GWO(initsol,fname,xmin,xmax,itermax);   
    Gw.bf = bestfit; Gw.fit = fitness; Gw.bs = bestsol; Gw.ct = time;
% %       save Gw Gw 

    disp('Coyote...')
    [bestfit,fitness,bestsol,time] = COA(initsol,fname,xmin,xmax,itermax);
    co.bf = bestfit; co.fit = fitness; co.bs = bestsol; co.ct = time;
% % %     save co co

    disp('Particle Swarm...')
    [bestfit,fitness,bestsol,time] = PSO(initsol,fname,xmin,xmax,itermax);
    pso.bf = bestfit; pso.fit = fitness; pso.bs = bestsol; pso.ct = time;
% %     save pso pso

    disp('proposed...')
    [bestfit,fitness,bestsol,time] = Adap_COA(initsol,fname,xmin,xmax,itermax);
    prop.bf = bestfit; prop.fit = fitness; prop.bs = bestsol; prop.ct = time;
% %     save prop prop
     
    % disp('Hippopotamus...')
    % [bestfit,fitness,bestsol,time] = HO(initsol,fname,xmin,xmax,itermax);
    % ho.bf = bestfit; ho.fit = fitness; ho.bs = bestsol; ho.ct = time;
% %     save ho ho
     
    % disp('Secretary bird ...')
    % [bestfit,fitness,bestsol,time] = SBOA(initsol,fname,xmin,xmax,itermax);
    % sboa.bf = bestfit; sboa.fit = fitness; sboa.bs = bestsol; sboa.ct = time;
% %     save sboa sboa

% Testing()
end
%  convergence()
%  plot_result()   %% real load
%  plot_result1()  %% reactive load
end