function [bestfit,fitness,bestsol,time] = SBOA(initsol,fname,xmin,xmax,itermax)
% Secretary Bird Optimization Algorithm (Fu et al., Artif. Intell. Rev., 2024).
% Interface identical to firefly/PSO/GWO. Objective evaluations: N + 2N per iteration.
tic
[N,D] = size(initsol);
lb = xmin(1,:);  ub = xmax(1,:);
X = min(max(initsol,lb),ub);
fit = zeros(N,1);
for i = 1:N, fit(i) = feval(fname,X(i,:)); end
[bestfit,ib] = min(fit);  bestsol = X(ib,:);
fitness = zeros(1,itermax);
for t = 1:itermax
    for i = 1:N
        % ---- hunting strategy (exploration -> exploitation) ----
        if t < itermax/3                               % searching for prey
            r1 = randi(N); r2 = randi(N);
            Xn = X(i,:) + (X(r1,:) - X(r2,:)).*rand(1,D);
        elseif t < 2*itermax/3                         % consuming prey (Brownian)
            RB = randn(1,D);
            Xn = bestsol + exp((t/itermax)^4)*(RB - 0.5).*(bestsol - X(i,:));
        else                                           % attacking prey (Levy)
            RL = 0.5*levy_step(D,1.5);
            Xn = bestsol + (1 - t/itermax)^(2*t/itermax)*X(i,:).*RL;
        end
        Xn = min(max(Xn,lb),ub);
        fn = feval(fname,Xn);
        if fn < fit(i), X(i,:) = Xn; fit(i) = fn; end
        % ---- escape strategy ----
        if rand < 0.5                                  % C1: camouflage
            RB = rand(1,D);
            Xn = bestsol + (2*RB - 1)*(1 - t/itermax)^2.*X(i,:);
        else                                           % C2: fly / run away
            K  = round(1 + rand);
            R2 = rand(1,D);
            Xn = X(i,:) + R2.*(X(randi(N),:) - K*X(i,:));
        end
        Xn = min(max(Xn,lb),ub);
        fn = feval(fname,Xn);
        if fn < fit(i), X(i,:) = Xn; fit(i) = fn; end
    end
    [m,ib] = min(fit);
    if m < bestfit, bestfit = m; bestsol = X(ib,:); end
    fitness(t) = bestfit;
end
time = toc;
end

function s = levy_step(D,beta)
sigma = (gamma(1+beta)*sin(pi*beta/2)/(gamma((1+beta)/2)*beta*2^((beta-1)/2)))^(1/beta);
u = randn(1,D)*sigma;  v = randn(1,D);
s = u./abs(v).^(1/beta);
end