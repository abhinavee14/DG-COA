function[tr_data,tr_tar,ts_data,ts_tar] = split_data(DATA,lp)

tr = round(size(DATA.IN,1)*(lp/100));
tr_data = DATA.IN(1:tr,:);
tr_tar = DATA.TAR(1:tr,:);
ts_data  = DATA.IN(1+tr:end,:);
ts_tar = DATA.TAR(1+tr:end,:);
end