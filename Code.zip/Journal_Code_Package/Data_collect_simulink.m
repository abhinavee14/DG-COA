function[] = Data_collect_simulink()
clc;
close all
warning off  
load R 
load V
    for i = 1:100
        fault_res = R;
        Nominal_vol=V;
        set_param('model/Fault2','FaultResistance',num2str(fault_res(i)))
        set_param('model/Load3','NominalVoltage',num2str(Nominal_vol(i)))
        
        out(i) = sim('model');
%         save out out
       end
        end